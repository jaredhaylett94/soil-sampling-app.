FIXED SINGLE-FILE PACKAGE

Open index.html directly after extracting ZIP. The ZIP reader is now embedded directly in index.html, so no vendor folder is needed. Map and drawing libraries still need internet.

FIELD MAPPER — SOIL SAMPLING PROTOTYPE (SHAPEFILE IMPORT UPDATE)

Open index.html in a browser with an internet connection. Map display and the original Leaflet drawing and shapefile-export libraries still load from public CDNs. The ZIP reader is bundled locally in vendor/jszip.min.js.

Import: select a .zip containing matching .shp, .shx, .dbf files and preferably a .prj file. Supports WGS 84 longitude/latitude (EPSG:4326) point, polyline and polygon features, including their DBF attributes. Projected shapefiles (such as UTM or State Plane) must be re-exported in EPSG:4326 before import. A ZIP with no .prj is assumed to be WGS84; verify coordinates before field use.

This is a prototype, not a production navigation system. Offline map downloads, cloud sync, Agvance SKY integration and background GPS tracking are not implemented. Export a backup before replacing browsers or clearing data.
